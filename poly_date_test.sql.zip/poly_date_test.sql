--
-- Database: `poly_date_test`
--
CREATE DATABASE IF NOT EXISTS `poly_date_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `poly_date_test`;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `identities`
--

CREATE TABLE `identities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `identities_users`
--

CREATE TABLE `identities_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `identity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `identities_users`
--

INSERT INTO `identities_users` (`id`, `user_id`, `identity_id`) VALUES
(1, 2103, 61),
(2, 2104, 62),
(3, 2104, 63),
(4, 2127, 67),
(5, 2128, 68),
(6, 2128, 69),
(7, 2151, 73),
(8, 2152, 74),
(9, 2152, 75),
(10, 2176, 81),
(11, 2177, 82),
(12, 2177, 83),
(13, 2202, 92),
(14, 2203, 93),
(15, 2203, 94),
(16, 2252, 103),
(17, 2253, 104),
(18, 2253, 105),
(19, 2275, 114),
(20, 2276, 115),
(21, 2276, 116),
(22, 2298, 125),
(23, 2299, 126),
(24, 2299, 127),
(25, 2321, 136),
(26, 2322, 137),
(27, 2322, 138),
(28, 2365, 155),
(29, 2366, 156),
(30, 2366, 157),
(31, 2412, 166),
(32, 2413, 167),
(33, 2413, 168),
(34, 2439, 177),
(35, 2440, 178),
(36, 2440, 179),
(37, 2466, 188),
(38, 2467, 189),
(39, 2467, 190),
(40, 2493, 199),
(41, 2494, 200),
(42, 2494, 201),
(43, 2520, 210),
(44, 2521, 211),
(45, 2521, 212),
(46, 2547, 221),
(47, 2548, 222),
(48, 2548, 223),
(49, 2574, 232),
(50, 2575, 233),
(51, 2575, 234),
(52, 2601, 243),
(53, 2602, 244),
(54, 2602, 245),
(55, 2627, 256),
(56, 2628, 257),
(57, 2628, 258),
(58, 2653, 269),
(59, 2654, 270),
(60, 2654, 271),
(61, 2679, 282),
(62, 2680, 283),
(63, 2680, 284),
(64, 2705, 295),
(65, 2706, 296),
(66, 2706, 297),
(67, 2729, 308),
(68, 2730, 309),
(69, 2730, 310),
(70, 2753, 322),
(71, 2754, 323),
(72, 2754, 324),
(73, 2783, 336),
(74, 2784, 337),
(75, 2784, 338),
(76, 2813, 350),
(77, 2814, 351),
(78, 2814, 352),
(79, 2849, 369),
(80, 2850, 370),
(81, 2850, 371),
(82, 2885, 388),
(83, 2886, 389),
(84, 2886, 390),
(85, 2921, 407),
(86, 2922, 408),
(87, 2922, 409),
(88, 2957, 426),
(89, 2958, 427),
(90, 2958, 428),
(91, 2993, 445),
(92, 2994, 446),
(93, 2994, 447),
(94, 3029, 464),
(95, 3030, 465),
(96, 3030, 466),
(97, 3065, 483),
(98, 3066, 484),
(99, 3066, 485),
(100, 3101, 502),
(101, 3102, 503),
(102, 3102, 504);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `user_id` int(11) DEFAULT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kinks`
--

CREATE TABLE `kinks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages_users`
--

CREATE TABLE `messages_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages_users`
--

INSERT INTO `messages_users` (`id`, `user_id`, `message_id`) VALUES
(1, 2105, 206),
(2, 2106, 206),
(3, 2107, 207),
(4, 2108, 207),
(5, 2129, 208),
(6, 2130, 208),
(7, 2131, 209),
(8, 2132, 209),
(9, 2153, 210),
(10, 2154, 210),
(11, 2155, 211),
(12, 2156, 211),
(13, 2178, 212),
(14, 2179, 212),
(15, 2180, 213),
(16, 2181, 213),
(17, 2204, 214),
(18, 2205, 214),
(19, 2206, 215),
(20, 2207, 215),
(21, 2254, 216),
(22, 2255, 216),
(23, 2256, 217),
(24, 2257, 217),
(25, 2277, 218),
(26, 2278, 218),
(27, 2279, 219),
(28, 2280, 219),
(29, 2300, 220),
(30, 2301, 220),
(31, 2302, 221),
(32, 2303, 221),
(33, 2323, 222),
(34, 2324, 222),
(35, 2325, 223),
(36, 2326, 223),
(37, 2367, 224),
(38, 2368, 224),
(39, 2369, 225),
(40, 2370, 225),
(41, 2414, 226),
(42, 2415, 226),
(43, 2416, 227),
(44, 2417, 227),
(45, 2441, 228),
(46, 2442, 228),
(47, 2443, 229),
(48, 2444, 229),
(49, 2468, 230),
(50, 2469, 230),
(51, 2470, 231),
(52, 2471, 231),
(53, 2495, 232),
(54, 2496, 232),
(55, 2497, 233),
(56, 2498, 233),
(57, 2522, 234),
(58, 2523, 234),
(59, 2524, 235),
(60, 2525, 235),
(61, 2549, 236),
(62, 2550, 236),
(63, 2551, 237),
(64, 2552, 237),
(65, 2576, 238),
(66, 2577, 238),
(67, 2578, 239),
(68, 2579, 239),
(69, 2603, 240),
(70, 2604, 240),
(71, 2605, 241),
(72, 2606, 241),
(73, 2629, 242),
(74, 2630, 242),
(75, 2631, 243),
(76, 2632, 243),
(77, 2655, 244),
(78, 2656, 244),
(79, 2657, 245),
(80, 2658, 245),
(81, 2681, 246),
(82, 2682, 246),
(83, 2683, 247),
(84, 2684, 247),
(85, 2707, 248),
(86, 2708, 248),
(87, 2709, 249),
(88, 2710, 249),
(89, 2731, 250),
(90, 2732, 250),
(91, 2733, 251),
(92, 2734, 251),
(93, 2755, 252),
(94, 2756, 252),
(95, 2757, 253),
(96, 2758, 253),
(97, 2785, 254),
(98, 2786, 254),
(99, 2787, 255),
(100, 2788, 255),
(101, 2815, 256),
(102, 2816, 256),
(103, 2817, 257),
(104, 2818, 257),
(105, 2851, 258),
(106, 2852, 258),
(107, 2853, 259),
(108, 2854, 259),
(109, 2887, 260),
(110, 2888, 260),
(111, 2889, 261),
(112, 2890, 261),
(113, 2923, 262),
(114, 2924, 262),
(115, 2925, 263),
(116, 2926, 263),
(117, 2959, 264),
(118, 2960, 264),
(119, 2961, 265),
(120, 2962, 265),
(121, 2995, 266),
(122, 2996, 266),
(123, 2997, 267),
(124, 2998, 267),
(125, 3031, 268),
(126, 3032, 268),
(127, 3033, 269),
(128, 3034, 269),
(129, 3067, 270),
(130, 3068, 270),
(131, 3069, 271),
(132, 3070, 271),
(133, 3103, 272),
(134, 3104, 272),
(135, 3105, 273),
(136, 3106, 273);

-- --------------------------------------------------------

--
-- Table structure for table `relationships`
--

CREATE TABLE `relationships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id_one` int(11) DEFAULT NULL,
  `user_id_two` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `seeking_genders`
--

CREATE TABLE `seeking_genders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `identity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seeking_genders`
--

INSERT INTO `seeking_genders` (`id`, `user_id`, `identity_id`) VALUES
(1, 2112, 64),
(2, 2113, 65),
(3, 2113, 66),
(4, 2136, 70),
(5, 2137, 71),
(6, 2137, 72),
(7, 2160, 76),
(8, 2161, 77),
(9, 2162, 79),
(10, 2162, 80),
(11, 2185, 84),
(12, 2186, 85),
(13, 2187, 87),
(14, 2188, 90),
(15, 2188, 91),
(16, 2211, 95),
(17, 2212, 96),
(18, 2213, 100),
(19, 2214, 101),
(20, 2214, 102),
(21, 2261, 106),
(22, 2262, 107),
(23, 2263, 111),
(24, 2264, 112),
(25, 2264, 113),
(26, 2284, 117),
(27, 2285, 118),
(28, 2286, 122),
(29, 2287, 123),
(30, 2287, 124),
(31, 2307, 128),
(32, 2308, 129),
(33, 2309, 133),
(34, 2310, 134),
(35, 2310, 135),
(36, 2330, 139),
(37, 2331, 140),
(38, 2332, 144),
(39, 2333, 145),
(40, 2333, 146),
(41, 2374, 158),
(42, 2375, 159),
(43, 2376, 163),
(44, 2377, 164),
(45, 2377, 165),
(46, 2421, 169),
(47, 2422, 170),
(48, 2423, 174),
(49, 2424, 175),
(50, 2424, 176),
(51, 2448, 180),
(52, 2449, 181),
(53, 2450, 185),
(54, 2451, 186),
(55, 2451, 187),
(56, 2475, 191),
(57, 2476, 192),
(58, 2477, 196),
(59, 2478, 197),
(60, 2478, 198),
(61, 2502, 202),
(62, 2503, 203),
(63, 2504, 207),
(64, 2505, 208),
(65, 2505, 209),
(66, 2529, 213),
(67, 2530, 214),
(68, 2531, 218),
(69, 2532, 219),
(70, 2532, 220),
(71, 2556, 224),
(72, 2557, 225),
(73, 2558, 229),
(74, 2559, 230),
(75, 2559, 231),
(76, 2583, 235),
(77, 2584, 236),
(78, 2585, 240),
(79, 2586, 241),
(80, 2586, 242),
(81, 2610, 246),
(82, 2611, 247),
(83, 2612, 251),
(84, 2613, 252),
(85, 2613, 253),
(86, 2620, 254),
(87, 2620, 255),
(88, 2622, 254),
(89, 2636, 259),
(90, 2637, 260),
(91, 2638, 264),
(92, 2639, 265),
(93, 2639, 266),
(94, 2646, 267),
(95, 2646, 268),
(96, 2648, 267),
(97, 2662, 272),
(98, 2663, 273),
(99, 2664, 277),
(100, 2665, 278),
(101, 2665, 279),
(102, 2672, 280),
(103, 2672, 281),
(104, 2674, 280),
(105, 2688, 285),
(106, 2689, 286),
(107, 2690, 290),
(108, 2691, 291),
(109, 2691, 292),
(110, 2698, 293),
(111, 2698, 294),
(112, 2700, 293),
(113, 2714, 298),
(114, 2715, 299),
(115, 2716, 303),
(116, 2717, 304),
(117, 2717, 305),
(118, 2738, 311),
(119, 2739, 312),
(120, 2740, 316),
(121, 2741, 317),
(122, 2741, 318),
(123, 2762, 325),
(124, 2763, 326),
(125, 2764, 330),
(126, 2765, 331),
(127, 2765, 332),
(128, 2772, 335),
(129, 2772, 334),
(130, 2774, 333),
(131, 2775, 333),
(132, 2776, 334),
(133, 2777, 335),
(134, 2778, 333),
(135, 2792, 339),
(136, 2793, 340),
(137, 2794, 344),
(138, 2795, 345),
(139, 2795, 346),
(140, 2802, 349),
(141, 2802, 348),
(142, 2804, 347),
(143, 2805, 347),
(144, 2806, 348),
(145, 2807, 349),
(146, 2808, 347),
(147, 2822, 353),
(148, 2823, 354),
(149, 2824, 358),
(150, 2825, 359),
(151, 2825, 360),
(152, 2826, 361),
(153, 2826, 362),
(154, 2838, 368),
(155, 2838, 367),
(156, 2840, 366),
(157, 2841, 366),
(158, 2842, 367),
(159, 2843, 368),
(160, 2844, 366),
(161, 2858, 372),
(162, 2859, 373),
(163, 2860, 377),
(164, 2861, 378),
(165, 2861, 379),
(166, 2862, 380),
(167, 2862, 381),
(168, 2874, 387),
(169, 2874, 386),
(170, 2876, 385),
(171, 2877, 385),
(172, 2878, 386),
(173, 2879, 387),
(174, 2880, 385),
(175, 2894, 391),
(176, 2895, 392),
(177, 2896, 396),
(178, 2897, 397),
(179, 2897, 398),
(180, 2898, 399),
(181, 2898, 400),
(182, 2910, 406),
(183, 2910, 405),
(184, 2912, 404),
(185, 2913, 404),
(186, 2914, 405),
(187, 2915, 406),
(188, 2916, 404),
(189, 2930, 410),
(190, 2931, 411),
(191, 2932, 415),
(192, 2933, 416),
(193, 2933, 417),
(194, 2934, 418),
(195, 2934, 419),
(196, 2946, 425),
(197, 2946, 424),
(198, 2948, 423),
(199, 2949, 423),
(200, 2950, 424),
(201, 2951, 425),
(202, 2952, 423),
(203, 2966, 429),
(204, 2967, 430),
(205, 2968, 434),
(206, 2969, 435),
(207, 2969, 436),
(208, 2970, 437),
(209, 2970, 438),
(210, 2982, 444),
(211, 2982, 443),
(212, 2984, 442),
(213, 2985, 442),
(214, 2986, 443),
(215, 2987, 444),
(216, 2988, 442),
(217, 3002, 448),
(218, 3003, 449),
(219, 3004, 453),
(220, 3005, 454),
(221, 3005, 455),
(222, 3006, 456),
(223, 3006, 457),
(224, 3018, 463),
(225, 3018, 462),
(226, 3020, 461),
(227, 3021, 461),
(228, 3022, 462),
(229, 3023, 463),
(230, 3024, 461),
(231, 3038, 467),
(232, 3039, 468),
(233, 3040, 472),
(234, 3041, 473),
(235, 3041, 474),
(236, 3042, 475),
(237, 3042, 476),
(238, 3054, 482),
(239, 3054, 481),
(240, 3056, 480),
(241, 3057, 480),
(242, 3058, 481),
(243, 3059, 482),
(244, 3060, 480),
(245, 3074, 486),
(246, 3075, 487),
(247, 3076, 491),
(248, 3077, 492),
(249, 3077, 493),
(250, 3078, 494),
(251, 3078, 495),
(252, 3090, 501),
(253, 3090, 500),
(254, 3092, 499),
(255, 3093, 499),
(256, 3094, 500),
(257, 3095, 501),
(258, 3096, 499),
(259, 3110, 505),
(260, 3111, 506),
(261, 3112, 510),
(262, 3113, 511),
(263, 3113, 512),
(264, 3114, 513),
(265, 3114, 514);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` text NOT NULL,
  `password` text NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `kink_friendly` tinyint(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `about_me` text,
  `interests` varchar(255) DEFAULT NULL,
  `seeking_relationship_type` varchar(255) DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `city_id` int(11) NOT NULL,
  `zip_code_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `first_name`, `last_name`, `status`, `kink_friendly`, `birthday`, `email`, `about_me`, `interests`, `seeking_relationship_type`, `last_login`, `city_id`, `zip_code_id`, `id`) VALUES
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3120),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3121),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3122),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3123),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3124),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3125),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3126),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3127),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3128),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3129),
('jwuerch', 'xyz', 'Jason', 'JMoney', 'Single', 1, '1989-03-07', 'wuerchjason@gmail.com', 'I am friendly.', 'Basketball, Tennis', 'Primary Partner', '1989-03-07', 1, 1, 3130);

-- --------------------------------------------------------

--
-- Table structure for table `zip_codes`
--

CREATE TABLE `zip_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zip_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `identities`
--
ALTER TABLE `identities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `identities_users`
--
ALTER TABLE `identities_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `kinks`
--
ALTER TABLE `kinks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages_users`
--
ALTER TABLE `messages_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `relationships`
--
ALTER TABLE `relationships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `seeking_genders`
--
ALTER TABLE `seeking_genders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `zip_codes`
--
ALTER TABLE `zip_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=716;
--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `identities`
--
ALTER TABLE `identities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=518;
--
-- AUTO_INCREMENT for table `identities_users`
--
ALTER TABLE `identities_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;
--
-- AUTO_INCREMENT for table `kinks`
--
ALTER TABLE `kinks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;
--
-- AUTO_INCREMENT for table `messages_users`
--
ALTER TABLE `messages_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
--
-- AUTO_INCREMENT for table `relationships`
--
ALTER TABLE `relationships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seeking_genders`
--
ALTER TABLE `seeking_genders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3131;
--
-- AUTO_INCREMENT for table `zip_codes`
--
ALTER TABLE `zip_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=534;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
